import pandas as pd
import pickle
import streamlit as st
import sklearn

# Function to load the trained model
def load_model(model_filename):
    try:
        with open(model_filename, 'rb') as file:
            loaded_model = pickle.load(file)
        return loaded_model
    except FileNotFoundError:
        st.error("Model file not found. Make sure the model file exists at the specified path.")
        return None
    except Exception as e:
        st.error(f"An error occurred while loading the model: {e}")
        return None

# Function to make a prediction
def predict_price(loaded_model, input_data):
    try:
        prediction = loaded_model.predict(input_data)[0]
        return prediction
    except Exception as e:
        st.error(f"An error occurred while making the prediction: {e}")
        return None

# Main function for Streamlit app
def main():
    # Load the clean car dataset
    df = pd.read_csv("clean_car_dataset.csv")
    
    # Drop the 'name' column
    df = df.drop('name', axis=1)
    
    # Load the trained model
    model_filename = 'model_selling_price.pkl'
    loaded_model = load_model(model_filename)

    if loaded_model is not None:
        # Streamlit app
        st.title('🚗 Used Car Selling Price Prediction App')
        st.header('Fill in the details to predict the used car selling price')

        # Input fields
        year = st.selectbox('Year', df['year'].unique())
        km_driven = st.number_input('Enter the kilometers reading of the vehicle', value=300000, min_value=0)
        fuel = st.selectbox('Fuel', df['fuel'].unique())
        seller_type = st.selectbox('Seller Type', df['seller_type'].unique())
        transmission = st.selectbox('Transmission', df['transmission'].unique(), index=0)
        owner = st.selectbox('Owner', df['owner'].unique())
        car_maker = st.selectbox('Brand', df['car_maker'].unique())
        car_model = st.selectbox('Car Model', df['car_model'].unique())

        # Button to make a prediction
        prediction_button = st.button('Predict Selling Price')

        # Check if the prediction button is clicked
        if prediction_button:
            # Prepare the input data as a DataFrame
            input_data = pd.DataFrame({
                'year': [year],
                'km_driven': [km_driven],
                'fuel': [fuel],
                'seller_type': [seller_type],
                'transmission': [transmission],
                'owner': [owner],
                'car_maker': [car_maker],
                'car_model': [car_model]
            })


            # Check the number of columns before one-hot encoding
            st.write(f"Number of columns before one-hot encoding: {df.shape[1]}")
            column_to_numerical = ['fuel', 'seller_type', 'transmission', 'owner', 'car_maker', 'car_model']

# Perform one-hot encoding on the input data
            input_data_encoded = pd.get_dummies(df, columns=column_to_numerical, drop_first=True)
            input_data_encoded.drop('selling_price', axis=1,inplace=True)

# Check the number of columns after one-hot encoding
            st.write(f"Number of columns after one-hot encoding: {input_data_encoded.shape[1]}")
            
            st.markdown("### Prediction Results")
            st.sidebar.markdown('Predicted Selling Price')

            # Make the prediction
            prediction = predict_price(loaded_model, input_data_encoded)

            if prediction is not None:
                st.write('The predicted selling price of the used car is', prediction, 'Rs.')

if __name__ == '__main__':
    main()
